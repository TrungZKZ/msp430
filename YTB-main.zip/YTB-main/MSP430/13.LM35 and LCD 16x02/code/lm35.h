
#include "msp430g2553.h"

void init_lm35(void);
int read_lm35(void);