
#include "msp430g2553.h"

long map(long x, long in_min, long in_max, long out_min, long out_max);
void init_sensor(void);
int read_sensor(void);